# Rails Backend Challenge - Instructions

## Overview

This challenge tests your ability to work with queries, validations, refactoring, and debugging in a Rails application.

## Setup

Start the development environment with Docker Compose from the project root:

```bash
docker compose up
```

All tests should pass initially. Your task is to implement the features described below while maintaining passing tests.

See the root [DOCKER.md](../DOCKER.md) for detailed setup instructions.

---

## Tasks

### Task 1: ActiveRecord Query & Associations

**Objective**: Implement a class method on `User` that returns all users who have placed more than a specified number of orders since a given date, along with the count of those orders.

**Requirements**:
- Use `joins`, `group`, `having` efficiently
- Implement as `.with_order_counts(min:, since:)` where:
  - `min` is the minimum number of orders
  - `since` is the date to check from
- Write tests in `spec/models/user_spec.rb`

**Example Usage**:
```ruby
# Get users with more than 5 orders in the last 30 days
User.with_order_counts(min: 5, since: 30.days.ago)
```

**What we're looking for**:
- Efficient SQL query (single database query)
- Proper use of ActiveRecord associations
- Appropriate test coverage

---

### Task 2: Validations & Scopes

**Objective**: Add validations and scopes to the `Order` model.

**Requirements**:

1. **Validation**: Validate that `total` is always positive
   - Should reject orders with negative or zero totals
   - Include an appropriate error message

2. **Scope**: Add a scope `.high_value` returning orders with totals above 100
   - Should be chainable with other scopes
   - Should return an ActiveRecord::Relation

**Tests**: Write tests in `spec/models/order_spec.rb`

**Example Usage**:
```ruby
# Validation
order = Order.new(user: user, total: -10)
order.valid? # => false

# Scope
Order.high_value # => returns all orders with total > 100
```

---

### Task 3: Service Object Refactor

**Objective**: Create a service class `CreateOrder` in `app/services/create_order.rb`.

**Requirements**:
- Accept a user and total as parameters
- Validate input before creating the order
- Create an order if validation passes
- Return a result object indicating success/failure
- Handle edge cases (nil user, invalid total, etc.)

**Interface**:
```ruby
result = CreateOrder.call(user: user, total: 100)
result.success? # => true/false
result.order    # => Order object (if successful)
result.errors   # => Array of error messages (if failed)
```

**Tests**: Write tests in `spec/services/create_order_spec.rb`

**What we're looking for**:
- Clean service object pattern
- Proper error handling
- Clear interface and return values
- Comprehensive test coverage

---

### Task 4: Debugging / Performance

**Objective**: Identify and fix an N+1 query problem.

**The Problem**:
The method below is inefficient and may cause N+1 queries:

```ruby
def recent_order_totals
  orders.last(5).map(&:total)
end
```

**Requirements**:
1. **Explain** why this method is inefficient (document in comments or in SOLUTIONS.md)
2. **Refactor** it to avoid N+1 queries
3. **Add expectations** in `spec/models/user_spec.rb` to verify the optimization

**Hints**:
- Consider how `last(5)` executes
- Think about eager loading
- Use `pluck` or similar methods where appropriate

**What we're looking for**:
- Understanding of N+1 query problems
- Knowledge of ActiveRecord query optimization techniques
- Ability to verify performance improvements in tests

---

### Bonus: Async Job

**Objective**: Understand and work with background jobs using Solid Queue.

A sample job `SampleJob` has been added to the application.

**To enqueue a job**:
```ruby
SampleJob.perform_later("Candidate")
```

**To run the worker**:
```bash
bin/jobs
```

**Optional Tasks**:
- Create a new background job
- Add error handling to the job
- Test the job execution

---

## Testing

Run the test suite frequently to verify your implementations:

```bash
bundle exec rspec
```

Run specific test files:

```bash
bundle exec rspec spec/models/user_spec.rb
bundle exec rspec spec/services/create_order_spec.rb
```

---

## Submission Guidelines

1. **Code**: Implement all required functionality
2. **Tests**: Ensure all tests pass
3. **Documentation**: Complete [SOLUTIONS.md](./SOLUTIONS.md) with:
   - Your approach to each task
   - Any trade-offs or decisions you made
   - Explanations for Task 4 (N+1 query problem)

---

## Tips

- Read through all tasks before starting
- Start with the task you feel most comfortable with
- Write tests as you go (or ensure existing tests pass)
- Comment your code where the logic isn't obvious
- Don't hesitate to refactor as you learn more about the codebase

Good luck! 🚀
