class User < ApplicationRecord
  has_many :orders, dependent: :destroy

  def self.with_order_counts(min: 5, since: 30.days.ago)
    raise ArgumentError, "since can't be nil" if since.nil?
    raise ArgumentError, "min must be >= 0" if min.negative?

    joins(:orders)
      .where(orders: { created_at: since.. })
      .group(:id)
      .having("COUNT(orders.id) > ?", min)
      .select("users.*, COUNT(orders.id) AS order_count")
  end

  def recent_order_totals
    orders.order(id: :desc).limit(5).pluck(:total).reverse
  end
end
