class Order < ApplicationRecord
  belongs_to :user

  validates :total, numericality: { greater_than: 0 }

  scope :high_value, -> { where("total > ?", 100).order(:id) }
end
