module Types
  class QueryType < Types::BaseObject
    field :users, [ Types::UserType ], null: false do
      description "Returns a list of users"
    end

    def users
      User.all
    end

    field :orders, [ Types::OrderType ], null: false do
      description "Returns a list of orders"
    end

    def orders
      Order.all
    end
  end
end
