module Types
  class OrderType < Types::BaseObject
    field :id, ID, null: false
    field :total, Integer, null: false
    field :user, Types::UserType, null: false
  end
end
