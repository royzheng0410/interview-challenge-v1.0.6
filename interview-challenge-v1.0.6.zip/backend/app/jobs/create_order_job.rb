class CreateOrderJob < ApplicationJob
  queue_as :default

  def perform(user_id, total)
    user = User.find_by(id: use_id)

    return unless user

    result = CreateOrder.call(user:, total:)

    if result.failure?
      # log `result.errors`, increase order creation failure metrics
    else
      # increase order creation success metrics
    end
  end
end
