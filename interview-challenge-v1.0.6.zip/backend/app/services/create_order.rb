class CreateOrder
  # user::    <User>
  # total::   <Integer>
  # Returns:: <CreateOrder::Result>
  def self.call(user: nil, total: 0)
    new(user:, total:).call
  end

  def initialize(user:, total:)
    @user = user
    @total = total.to_i
  end

  def call
    return Result.new(errors: [ "Invalid argument - user: User must be present" ]) if user.nil? || !user.instance_of?(User)
    return Result.new(errors: [ "Invalid argument - total: Order total must be greater than 0" ]) unless total.positive?

    order = Order.create(user:, total:)
    Result.new(order:)
  end

  private

  attr_reader :user, :total

  class Result
    attr_reader :order, :errors

    def initialize(order: nil, errors: nil)
      @order = order
      @errors = errors || order.errors.full_messages
    end

    def success?
      errors.empty?
    end

    def failure?
      !success?
    end
  end
end
