# Backend Challenge - Solutions

**Candidate Name**: Chen Zheng
**Date**: 12th Oct, 2026
**Time Spent**: 3hrs

---

## Task 1: ActiveRecord Query & Associations

### Implementation Approach

- Fix the N+1 issue by using a join statement between `User` and `Order`, aggregating each user's order count directly in SQL instead of loading `Order` records into Ruby.
- Fix the in-memory calculation issue by using `group` and `having` SQL clauses and the `COUNT` aggregate function to calculate and filter users by order count directly in the database.
- Add guard clauses to validate inputs, so invalid `since`/`min` values raise an error instead of silently changing the query's meaning (e.g. `since: nil` would otherwise drop the date filter, and a negative `min` would otherwise match almost every user).

### Key Decisions

- Use `.joins` (translated to `INNER JOIN`) to exclude, at the DB level, any user with no orders matching the `since`/`min` criteria — not just users with zero orders overall.
- Add guard clauses for `since` and `min` that raise an error to ensure input integrity.
- Didn't add an index on `orders.created_at`, given the small data set.

### SQL Query

```sql
EXPLAIN SELECT users.*, COUNT(orders.id) AS order_count FROM "users" INNER JOIN "orders" ON "orders"."user_id" = "users"."id" WHERE "orders"."created_at" >= '2026-09-12 00:04:26.685039' GROUP BY "users"."id" HAVING (COUNT(orders.id) > 5) /*application='RailsChallenge'*/

                                           QUERY PLAN
-------------------------------------------------------------------------------------------------
 HashAggregate  (cost=38.33..40.97 rows=70 width=64)
   Group Key: users.id
   Filter: (count(orders.id) > 5)
   ->  Nested Loop  (cost=0.16..37.28 rows=211 width=64)
         ->  Seq Scan on orders  (cost=0.00..8.03 rows=211 width=12)
               Filter: (created_at >= '2026-09-12 00:04:26.685039'::timestamp without time zone)
         ->  Memoize  (cost=0.16..0.40 rows=1 width=56)
               Cache Key: orders.user_id
               Cache Mode: logical
               ->  Index Scan using users_pkey on users  (cost=0.15..0.39 rows=1 width=56)
                     Index Cond: (id = orders.user_id)
(11 rows)
```

### Testing Strategy

- Added unit tests for the happy path.
- Added unit tests for error handling/edge cases where inputs are invalid.
- Manually ran the method in the Rails console to compare performance pre/post fix. The new solution took **6.1ms** to finish — almost a **95% drop in latency** versus the original naive implementation (178.7ms for the initial `User Load` alone, before even starting its 40 N+1 `Order Count` queries).

---

## Task 2: Validations & Scopes

### Validation Implementation

- Use ActiveRecord validators for the integer `total` field, which ships with a default error message that is sufficient for the requirement.

### Scope Implementation

- Use the ActiveRecord query interface to define a reusable scope which queries all orders with a total over 100.

### Edge Cases Considered

- Total is nil
- Total is 0
- Total is negative
- Total is decimal
- Sorting order for results of scope query

---

## Task 3: Service Object Refactor

### Service Design

- A service object that has a public class interface `.call`, which takes a user and total as input.
- The class-level `.call` initializes an object and executes the instance method `.call` on it, which is responsible for input validation, order creation, and returning a result object accordingly.
- A private `Result` class which exposes 4 states, `success?`, `failure?`, `order`, and `errors` — this is the only object returned from this service object.

### Error Handling

Errors are encapsulated inside a `Result` instance, and it could contain the following errors:
- Invalid input, when user is nil or not a proper object; when total is not a valid positive integer.
- Validation errors during order creation.

### Result Object

- A private class which exposes 4 public interfaces: `success?`, `failure?`, `order`, and `errors` — this is the only object returned from this service.
- `order` could be `nil` when inputs are invalid.
- `success?` is based on the presence of the `errors` state.
- None of the state is mutable from outside of the class.

### Alternative Approaches Considered

- To be more DDD, where the structure would be `/services/orders/create.rb`, to group all actions belonging to one domain together for better maintainability. Didn't change this for simplicity.
- Avoid explicitly checking that user is an instance of `User`, and instead have a `try`/`rescue` block around `Order.create(user:, total:)`. Chose the current solution for explicitness.
- Using a `Data` object vs. a class for the result object. Decided to use a class for the flexibility of the definition of success and failure, which could be easily altered in the class definition. Also allows for a more elegant class interface such as `self.success`/`self.failure` in the future.

---

## Task 4: Debugging / Performance

### Problem Analysis

**Why the original method is inefficient:**

N+1 isn't actually a property a single method call can have in isolation — it requires multiplicity (1 query for a list + N queries, one per item). A single call to `user.recent_order_totals` is just "1 query," so by itself it was never N+1. Distinguishing what the original code actually has:

- **Called once, cold** (association not yet loaded) — already fine before this fix: `orders.last(5)` issues a single `ORDER BY id DESC LIMIT 5` query, same shape as the refactored version. No bug here.
- **Called once, with `orders` already loaded elsewhere in the request** (e.g. via `includes(:orders)` for an unrelated reason) — this is the real bug: `.last(5)` on an already-loaded association does **not** re-query with `ORDER BY`/`LIMIT`; it just takes the last 5 of whatever's already in memory. Since the preload that populated it had no bound, that means the *entire* order history for that user gets loaded just to read 5 totals. An unbounded over-fetch, not N+1 — still exactly one query, just a much bigger one than necessary.
- **Called in a loop across many users without preloading** — this is where N+1 genuinely lives: 1 query for the user list + N queries, one per `recent_order_totals` call. Present equally in the old and new code, and not fixable from inside this method at all — the method only ever sees one user's orders and has no visibility into being called in a loop. A real fix would need a different shape entirely (e.g. a batch method using a window function to fetch "last 5 per user" for many users in one query), which is out of scope for this refactor.

The fix below addresses the middle case (unbounded over-fetch) and reduces the cost of the loop case per-call (fewer columns, no object instantiation) without eliminating it.

### Solution

- Use explicit `order` and `pluck` to only fetch `total`.
- Reverse the result to mimic the Rails internal reverse order operation on `.last()`.

### Performance Improvement

- Measured gain is minimal on this dataset — on a cold/unloaded association, both the original `.last(5)` and the refactored query execute the same `ORDER BY id DESC LIMIT 5` SQL, so `pluck`'s benefit here is really just fetching 1 column instead of 5 and skipping `Order` object instantiation, not a different query plan.
- The bigger value isn't raw speed, it's predictability: `.last(5)` silently loads a user's entire order history (no `ORDER BY`/`LIMIT` at all) if `orders` happens to already be loaded elsewhere in the request; the refactored version always runs the same bounded query regardless of that state.

### Verification

- Benchmarked both versions in the Rails console, averaging 30 runs with a freshly-fetched (cold) user each time to remove process warm-up noise: ~2.4ms (old) vs ~2.0ms (new) — a small, consistent difference, not a dramatic one. Likely more pronounced on a larger per-user order count, but not retested at scale.

---

## Bonus: Async Job (Optional)

I added a sample create_order_job.rb which could be enqueued to create a order in background

---

## General Notes

### Challenges Faced

- Took a me a while to get my head around the double reverse underneath .last() implementation, but TIL

- Not be able to comprehend the N + 1 issue in Task 4

- Not be able to execute the create order worker



### What You Would Do Differently With More Time

- Add public interface (self.succeed, self.fail) for CreatOrder::Result, and add try rescue around Order.create(user:, total:) statement to be able to explicitly call .succeed and .fail on Result

- Add dataloader to prevent N + 1 issue for the GraphQL API

- Type my solution out in SOLUTIONS.md first instead of to the Agent.

- Maybe start with Task 4 first.


### Questions or Clarifications

- For Task 1, a index on create_at could help improve effiency even furthure but I assume it's out of scope for now.

- For Task 2, I added sort by ID ASC to be a bit more deterministic on the order of return value, also an index of total in order table could help improve performance of the scope.

- I am still a bit confused about task 4, especially around identifying N + 1 issues for an instanse method. I understand that it could be escalate into a N + 1 issue when the method gets called in an iteration of Users, but I feel it could not be solved without changing the signature of the method.



---

## Self-Assessment

- [ + ] All tests pass
- [ + ] Code follows Rails conventions
- [ ~ ] Code is well-documented
- [ + ] Edge cases are handled
- [ ~ ] Performance is optimized

---

Thank you for reviewing my submission!
