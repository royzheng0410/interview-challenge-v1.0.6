require "rails_helper"
RSpec.describe "GraphQL", type: :request do
  it "fetches users and their orders" do
    post "/graphql", params: { query: "{ users { id name orders { id total } } }" }
    expect(response).to have_http_status(:ok)
    json = JSON.parse(response.body)
    expect(json["data"]["users"]).to be_an(Array)
  end
end
