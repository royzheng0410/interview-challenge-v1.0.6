require "rails_helper"

RSpec.describe Order, type: :model do
  describe "validations" do
    it "rejects a negative total" do
      user = User.create!(name: "Alice")
      order = Order.new(user: user, total: -10)

      expect(order).not_to be_valid
      expect(order.errors[:total]).to include("must be greater than 0")
    end

    it "rejects a zero total" do
      user = User.create!(name: "Bob")
      order = Order.new(user: user, total: 0)

      expect(order).not_to be_valid
      expect(order.errors[:total]).to include("must be greater than 0")
    end

    it "rejects a nil total" do
      user = User.create!(name: "Carol")
      order = Order.new(user: user, total: nil)

      expect(order).not_to be_valid
      expect(order.errors[:total]).to include("is not a number")
    end

    it "accepts a positive total" do
      user = User.create!(name: "Dave")
      order = Order.new(user: user, total: 1)

      expect(order).to be_valid
    end

    it "coerces a decimal total into an integer and validates the coerced value" do
      user = User.create!(name: "Erin")
      order = Order.new(user: user, total: 1.2)

      expect(order.total).to eq(1)
      expect(order).to be_valid
    end
  end

  describe ".high_value" do
    it "includes orders with a total greater than 100" do
      user = User.create!(name: "Frank")
      order = user.orders.create!(total: 101)

      expect(Order.high_value).to include(order)
    end

    it "excludes orders withser a total of exactly 100" do
      user = User.create!(name: "Grace")
      order = user.orders.create!(total: 100)

      expect(Order.high_value).not_to include(order)
    end

    it "excludes orders with a total below 100" do
      user = User.create!(name: "Heidi")
      order = user.orders.create!(total: 50)

      expect(Order.high_value).not_to include(order)
    end

    it "orders results by id ascending, for deterministic results" do
      user = User.create!(name: "Mallory")
      # Created out of id order on purpose: if the scope relied on insertion/scan
      # order instead of an explicit ORDER BY, this would return [second, first].
      second = Order.create!(id: 1_000_002, user: user, total: 150)
      first = Order.create!(id: 1_000_001, user: user, total: 200)

      expect(Order.high_value).to eq([ first, second ])
    end

    it "returns a chainable ActiveRecord::Relation" do
      user = User.create!(name: "Ivan")
      other_user = User.create!(name: "Judy")
      matching_order = user.orders.create!(total: 150)
      other_user.orders.create!(total: 150)

      expect(Order.high_value).to be_a(ActiveRecord::Relation)

      result = Order.high_value.where(user: user)

      expect(result).to be_a(ActiveRecord::Relation)
      expect(result).to contain_exactly(matching_order)
    end
  end
end
