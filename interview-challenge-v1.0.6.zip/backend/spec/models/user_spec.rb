require "rails_helper"

RSpec.describe User, type: :model do
  describe ".with_order_counts" do
    it "returns only users with more than the given number of orders since the given date, with each order count" do
      qualifying_user = User.create!(name: "Alice")
      below_threshold_user = User.create!(name: "Bob")
      stale_orders_user = User.create!(name: "Carol")

      6.times { qualifying_user.orders.create!(total: 10, created_at: 1.day.ago) }
      3.times { below_threshold_user.orders.create!(total: 10, created_at: 1.day.ago) }
      6.times { stale_orders_user.orders.create!(total: 10, created_at: 60.days.ago) }

      result = User.with_order_counts(min: 5, since: 30.days.ago)

      expect(result).to contain_exactly(qualifying_user)
      expect(result.first.order_count.to_i).to eq(6)
    end

    it "excludes users whose order count is equal to (not greater than) the minimum" do
      user = User.create!(name: "Dave")
      5.times { user.orders.create!(total: 10, created_at: 1.day.ago) }

      result = User.with_order_counts(min: 5, since: 30.days.ago)

      expect(result).to be_empty
    end

    it "only counts orders placed on or after the given date" do
      user = User.create!(name: "Erin")
      6.times { user.orders.create!(total: 10, created_at: 1.day.ago) }
      4.times { user.orders.create!(total: 10, created_at: 60.days.ago) }

      result = User.with_order_counts(min: 5, since: 30.days.ago)

      expect(result).to contain_exactly(user)
      expect(result.first.order_count.to_i).to eq(6)
    end

    it "raises when since is nil, instead of silently dropping the date filter" do
      expect { User.with_order_counts(min: 5, since: nil) }.to raise_error(ArgumentError)
    end

    it "raises when min is negative, instead of silently matching every user" do
      expect { User.with_order_counts(min: -1, since: 30.days.ago) }.to raise_error(ArgumentError)
    end
  end

  describe "#recent_order_totals" do
    it "returns the totals of the 5 most recent orders, oldest of the five first" do
      user = User.create!(name: "Frank")
      7.times { |i| user.orders.create!(total: i + 1) }

      expect(user.recent_order_totals).to eq([ 3, 4, 5, 6, 7 ])
    end

    it "returns all totals when fewer than 5 orders exist" do
      user = User.create!(name: "Grace")
      user.orders.create!(total: 10)
      user.orders.create!(total: 20)

      expect(user.recent_order_totals).to eq([ 10, 20 ])
    end

    it "returns an empty array when the user has no orders" do
      user = User.create!(name: "Heidi")

      expect(user.recent_order_totals).to eq([])
    end
  end
end
