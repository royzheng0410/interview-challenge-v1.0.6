require "rails_helper"

RSpec.describe CreateOrder do
  describe ".call" do
    it "creates an order and returns a successful result for a valid user and total" do
      user = User.create!(name: "Alice")

      result = CreateOrder.call(user: user, total: 150)

      expect(result.order).to be_persisted
      expect(result.order.total).to eq(150)
      expect(result.errors).to eq([])
      expect(result.success?).to eq(true)
      expect(result.failure?).to eq(false)
    end

    it "returns a failed result when user is nil" do
      result = CreateOrder.call(user: nil, total: 150)

      expect(result.order).to be_nil
      expect(result.errors).to eq([ "Invalid argument - user: User must be present" ])
      expect(result.success?).to eq(false)
      expect(result.failure?).to eq(true)
    end

    it "returns a failed result when user is not a User" do
      result = CreateOrder.call(user: "not a user", total: 150)

      expect(result.order).to be_nil
      expect(result.errors).to eq([ "Invalid argument - user: User must be present" ])
      expect(result.success?).to eq(false)
      expect(result.failure?).to eq(true)
    end

    it "returns a failed result when total is zero" do
      user = User.create!(name: "Bob")

      result = CreateOrder.call(user: user, total: 0)

      expect(result.order).to be_nil
      expect(result.errors).to eq([ "Invalid argument - total: Order total must be greater than 0" ])
      expect(result.success?).to eq(false)
      expect(result.failure?).to eq(true)
    end

    it "returns a failed result when total is nil" do
      user = User.create!(name: "Carol")

      result = CreateOrder.call(user: user, total: nil)

      expect(result.order).to be_nil
      expect(result.errors).to eq([ "Invalid argument - total: Order total must be greater than 0" ])
      expect(result.success?).to eq(false)
      expect(result.failure?).to eq(true)
    end

    it "returns a failed result when total is negative" do
      user = User.create!(name: "Dave")

      result = CreateOrder.call(user: user, total: -10)

      expect(result.order).to be_nil
      expect(result.errors).to eq([ "Invalid argument - total: Order total must be greater than 0" ])
      expect(result.success?).to eq(false)
      expect(result.failure?).to eq(true)
    end

    it "returns a failed result when the created order fails model validation" do
      user = User.create!(name: "Erin")
      invalid_order = Order.new(user: user, total: 150)
      invalid_order.errors.add(:total, "is invalid for some other reason")
      allow(Order).to receive(:create).with(user: user, total: 150).and_return(invalid_order)

      result = CreateOrder.call(user: user, total: 150)

      expect(result.order).to eq(invalid_order)
      expect(result.errors).to eq([ "Total is invalid for some other reason" ])
      expect(result.success?).to eq(false)
      expect(result.failure?).to eq(true)
    end
  end
end
