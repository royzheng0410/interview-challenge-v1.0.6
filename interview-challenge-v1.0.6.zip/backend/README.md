# Rails Backend Challenge

Welcome! This challenge tests your ability to work with queries, validations, refactoring, and debugging in a Rails app.

## 📋 Important Files

- **[INSTRUCTIONS.md](./INSTRUCTIONS.md)**: Detailed task descriptions and requirements
- **[SOLUTIONS.md](./SOLUTIONS.md)**: Document your solutions and approach here
- **This file (README.md)**: Quick start and setup guide

## Quick Start

Use Docker Compose from the root directory:

```bash
# From project root
docker compose up
```

The backend API will be available at `http://localhost:3000`.

See the root [DOCKER.md](../DOCKER.md) for detailed instructions.

## What to Submit

1. Your code changes
2. Completed `SOLUTIONS.md` with your analysis and approach
3. Passing test suite
4. Any notes about trade-offs or decisions you made

## Available Commands

### Testing
```bash
bundle exec rspec                          # Run all tests
bundle exec rspec spec/models/user_spec.rb # Run specific test file
```

### Database
```bash
bin/rails db:migrate      # Run migrations
bin/rails db:seed         # Seed the database
bin/rails db:reset        # Reset database
bin/rails console         # Open Rails console
```

### Code Quality
```bash
bin/rubocop              # Run linter
bin/brakeman --no-pager  # Security scan
```

### Background Jobs
```bash
bin/jobs                 # Start Solid Queue worker
```

## Technology Stack

- **Ruby on Rails** 8.0
- **PostgreSQL** - Database
- **GraphQL** - API layer
- **Solid Queue** - Background jobs
- **RSpec** - Testing framework

## Project Structure

```
app/
├── models/          # ActiveRecord models
├── services/        # Service objects
├── graphql/         # GraphQL types and resolvers
└── jobs/            # Background jobs

spec/
├── models/          # Model tests
└── services/        # Service tests
```

## Tips

- Read [INSTRUCTIONS.md](./INSTRUCTIONS.md) thoroughly before starting
- Start with the task you feel most comfortable with
- Run tests frequently to verify your implementations
- Document your approach in [SOLUTIONS.md](./SOLUTIONS.md)
- Don't hesitate to add comments explaining your logic

Good luck! 🚀
