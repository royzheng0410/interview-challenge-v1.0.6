# Full Stack Interview Challenge

This repository contains both frontend and backend coding challenges designed to assess your full-stack development skills.

## 📁 Project Structure

```
.
├── backend/          # Rails API with GraphQL
├── frontend/         # React + TypeScript application
├── docker-compose.yml
└── DOCKER.md
```

## 🚀 Quick Start

Use Docker Compose to run both frontend and backend with all dependencies:

```bash
# Start all services
docker compose up

# Access the applications
# Frontend: http://localhost:5173
# Backend API: http://localhost:3000
# PostgreSQL: localhost:5432
```

**See [DOCKER.md](./DOCKER.md) for detailed instructions and troubleshooting.**


## 📋 Challenges

### Backend Challenge

**Location**: `backend/`

The Rails challenge focuses on:
- ActiveRecord queries and associations
- Validations and scopes
- Service object patterns
- Performance optimization and debugging
- Background jobs with Solid Queue

**Instructions**: See [backend/INSTRUCTIONS.md](./backend/INSTRUCTIONS.md)
**Overview**: See [backend/README.md](./backend/README.md)

### Frontend Challenge

**Location**: `frontend/`

The React/TypeScript challenge focuses on:
- Performance optimization
- State management
- Accessibility (a11y)
- API integration
- Component architecture

**Instructions**: See [frontend/INSTRUCTIONS.md](./frontend/INSTRUCTIONS.md)
**Overview**: See [frontend/README.md](./frontend/README.md)

## 🛠️ Technology Stack

### Backend
- Ruby on Rails 8.0
- PostgreSQL
- GraphQL
- Solid Queue (background jobs)
- RSpec (testing)

### Frontend
- React 18
- TypeScript
- Vite
- GraphQL Client (graphql-request)

## 📝 What to Submit

For each challenge:

1. **Code Changes**: Your implementation of the tasks
2. **Agent Session**: If you have used AI, please submit your agent session and transcripts alongside your submission
3. **Solutions Documentation**:
   - Backend: Complete [backend/SOLUTIONS.md](./backend/SOLUTIONS.md)
   - Frontend: Complete [frontend/SOLUTIONS.md](./frontend/SOLUTIONS.md)
4. **Notes**: Any assumptions, trade-offs, or decisions you made
5. **Passing Tests**: Tests should pass for the tasks you complete

## 🧪 Testing

### Backend Tests
```bash
cd backend
bundle exec rspec
```

### Frontend Linting & Type Checking
```bash
cd frontend
npm run lint
npx tsc --noEmit
```

## 🔍 Evaluation Criteria

Your submission will be evaluated on:

- **Full-Stack Capability**: Demonstrating competence in both backend and frontend
- **Prioritization**: How you allocate time and choose what to tackle
- **Stop at 4 hours** - Really. We're evaluating judgment, not endurance
- **Code Quality**: Clean, readable, and maintainable code
- **Correctness**: Solutions that meet the requirements
- **Best Practices**: Following framework conventions and patterns
- **Testing**: Appropriate test coverage
- **Performance**: Efficient implementations
- **Communication**: Clear documentation of your approach and decisions

## 📚 Additional Resources

### Documentation
- [DOCKER.md](./DOCKER.md) - Complete Docker development guide

### Backend Challenge
- [backend/README.md](./backend/README.md) - Quick start and overview
- [backend/INSTRUCTIONS.md](./backend/INSTRUCTIONS.md) - Detailed task descriptions
- [backend/SOLUTIONS.md](./backend/SOLUTIONS.md) - Solution template (fill this out)

### Frontend Challenge
- [frontend/README.md](./frontend/README.md) - Quick start and overview
- [frontend/INSTRUCTIONS.md](./frontend/INSTRUCTIONS.md) - Detailed task descriptions
- [frontend/SOLUTIONS.md](./frontend/SOLUTIONS.md) - Solution template (fill this out)

## ⏱️ Time Expectation

**Total Time**: 3-4 hours maximum

You don't need to complete everything - focus on demonstrating:
- Your approach and problem-solving process
- Quality implementations over quantity
- Good judgment about what to tackle and in what order
- Clear documentation of your decisions and what you would do next

## 💡 Tips

- **Review all tasks** in both challenges before starting
- **Plan your approach** - Decide what to tackle and in what order
- **Work across both challenges** - Touch both backend and frontend, even if you spend more time in your stronger area
- **Prioritize high-impact work** - Show you can identify what matters most
- **Document your decisions** - Explain what you chose to do and why
- **Test as you go** - Ensure what you complete actually works
- **Be honest** - If you run out of time, document what you would do next
- **Quality > Quantity** - A few well-executed solutions beat many incomplete ones

## 🆘 Getting Help

If you encounter setup issues:

1. Check the README files in each directory
2. Review [DOCKER.md](./DOCKER.md) for Docker troubleshooting
3. Ensure all dependencies are installed
4. Check that ports 3000, 5173, and 5432 are available

Good luck! 🚀
