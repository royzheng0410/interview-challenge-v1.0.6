# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this repo is

A take-home interview challenge with two independent, unfinished codebases that share nothing but a GraphQL contract:

- `backend/` — Rails 8 + GraphQL API (the candidate has deep Rails knowledge; least guidance needed here).
- `frontend/` — React 18 + TypeScript dashboard (the candidate wants more support on React idioms/conventions here).

Each side has its own `INSTRUCTIONS.md` (task spec — read before touching that side) and `SOLUTIONS.md` (template to fill in explaining approach/trade-offs — update it as tasks are completed, don't leave it for the end). Root `README.md` has the full brief; root `DOCKER.md` has Docker troubleshooting. Time-box: the brief says 3–4 hours total across both sides — prioritize high-impact fixes over completeness.

## Running things

Everything runs via Docker Compose from the repo root — there's no expectation of local Ruby/Node installs:

```bash
docker compose up          # Postgres :5432, backend :3000, frontend :5173, Solid Queue worker
docker compose up backend  # backend + its DB dependency only
docker compose logs -f backend   # or frontend / jobs
```

Backend runs `bin/rails db:prepare` on boot (creates DB, migrates, loads schema). Both sides hot-reload through the Docker volume mounts.

### Backend (run inside the container: `docker compose exec backend <cmd>`, or bare if working outside Docker)

```bash
bundle exec rspec                            # full suite
bundle exec rspec spec/models/user_spec.rb   # single file
bundle exec rspec path/to/spec.rb:LINE       # single example
bin/rubocop                                  # lint (rubocop-rails-omakase)
bin/brakeman --no-pager                      # security scan
bin/rails console
bin/jobs                                     # Solid Queue worker
```

### Frontend (run inside the container: `docker compose exec frontend <cmd>`, or bare if working outside Docker)

```bash
npm run dev            # vite dev server
npm run build           # production build
npm run lint             # eslint --max-warnings 0
npx tsc --noEmit         # type check (no dedicated test runner is configured)
```

## Backend architecture

Standard Rails + `graphql` gem layout — nothing exotic:

- `app/models/user.rb`, `app/models/order.rb` — `User has_many :orders`. Both models currently contain the challenge's unfinished/intentionally-naive code (see inline comments: `with_order_counts` is intentionally inefficient, `Order` validations/scope are `TODO`s).
- `app/services/create_order.rb` — empty service-object shell to implement (`.call` returning a result object with `success?`/`order`/`errors`).
- `app/graphql/` — schema entry point is `rails_challenge_schema.rb`; `types/query_type.rb` exposes `users`/`orders` root fields; `types/user_type.rb` and `types/order_type.rb` define the GraphQL shape consumed by the frontend's `BackendDataService`. GraphQL types are the API contract — if `UserType`/`OrderType` fields change, the frontend's `USERS_QUERY` and `GraphQLUser`/`GraphQLOrder` types (`frontend/src/types/index.ts`) must change in lockstep.
- Tests mirror app structure under `spec/{models,services,requests}`; `spec/requests/graphql_spec.rb` exercises the GraphQL endpoint end-to-end.
- Background jobs via Solid Queue (`app/jobs/sample_job.rb` is a working example); config in `config/queue.yml` / `config/recurring.yml`.

## Frontend architecture

Vite + React 18 + TypeScript, no component library, no CSS framework (plain CSS in `App.css`/`index.css`), no state-management library — state is local `useState`/Context. This is deliberately a "realistic legacy dashboard," so treat the existing code as the thing to be audited and improved, not a clean reference implementation.

**Data flow**: `App.tsx` holds `users`/`analytics`/`loading` state and fetches once per `dataService` change via `useEffect`. `dataService` comes from `ApiModeContext` (`contexts/ApiModeContext.tsx`), which picks an implementation through `DataServiceFactory` based on an `ApiMode` (`'mock' | 'backend'`), persisted to `localStorage` and togglable from `Header` — but only when `VITE_DEVELOPMENT=true`; in production mode it's hardcoded to `'backend'`.

**Swappable data layer** (`services/`): `DataService` is the interface; `MockDataService` generates **2,500 deterministic users client-side** (this volume is intentional — it's the performance stress test, not a bug) and simulates network latency (`delay(1500)`/`delay(800)`); `BackendDataService` hits the Rails GraphQL endpoint via `graphql-request` and reshapes `GraphQLUser`→`User` (string IDs → numbers). `AnalyticsCalculator` derives dashboard-wide aggregates from the full user list and is shared by both services — any analytics change should go there, not be duplicated per-component.

**Render tree**: `App` → `Header` (search input, sidebar toggle, mode switch) + `Sidebar` (renders `Analytics`) + `Dashboard` (filter/sort over all users, renders `UserTable` → `UserRow` per user, with expandable order detail rows).

## How we work

These apply to both sides of the challenge, but matter most on the frontend where fixes are often performance- or UX-shaped rather than a single obviously-correct implementation:

1. **Measure before and after.** For any performance-related fix, capture a concrete before number (render count, elapsed ms, profiler flamegraph, query count/time, bundle size — whatever's applicable) before changing code, then capture the same measurement after. A fix without a quantified before/after isn't done yet — "feels faster" doesn't count, and this evidence is also an explicit graded deliverable per the brief.
2. **One task at a time.** Don't attempt to solve every task in a single pass. Pick one task, finish it (including its measurement and its `SOLUTIONS.md` write-up), then move to the next. Resist the pull to "clean up" adjacent code while in the middle of an unrelated task.
3. **Explain root cause and trade-offs before writing code.** Before editing, state in a sentence or two *why* the current code is slow/wrong/inaccessible and what approach is chosen over the alternatives (and why). This should be short enough to drop straight into `SOLUTIONS.md`.
4. **Prefer the simplest readable fix over clever ones.** Optimize for what a reviewer can understand in one pass — a small, idiomatic change (e.g. `useMemo`, a DB index, a single query reshape) beats a more "impressive" but harder-to-follow rewrite. If two approaches both solve the problem, pick the one with less surface area and fewer new abstractions.

## Test-writing style (backend specs)

- Declare variables inline, inside each `it` block, rather than hoisting shared state into a top-level `let`/`before`. A reader should be able to understand one example by reading only that example, without scanning up to the `describe` block for hidden setup — even if that means repeating a literal like `30.days.ago` or `min: 5` across examples.
- Don't add instrumentation-style assertions (e.g. counting `sql.active_record` notifications to assert "exactly 1 query") to specs — the setup is verbose relative to the value, and it's easy to get the subscription API wrong. Verify query count/shape manually in the console (`ActiveRecord::Base.logger = Logger.new($stdout)`, run the call, read the log) and record the finding as a note in `SOLUTIONS.md` instead of encoding it as a test.
- `SOLUTIONS.md` write-ups are the user's own — don't fill them in. Flag findings (measurements, trade-offs, out-of-scope issues) back in conversation, or leave them as a note for later, rather than editing the doc.

## Conventions

- Backend: Rubocop uses `rubocop-rails-omakase` (Rails' house style) — defer to its defaults rather than imposing a different Ruby style.
- Frontend: strict-ish ESLint (`--max-warnings 0`, `eslint-plugin-react-hooks`) and `tsc --noEmit` are the gating checks; there is no Jest/Vitest/RTL configured, so "testing" on this side means manual verification in the browser plus lint/type-check, not unit tests.
- Keep `SOLUTIONS.md` (per side) updated as each task finishes, not just at the end — it's a graded deliverable, not optional documentation.
