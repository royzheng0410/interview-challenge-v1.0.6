# Docker Development Environment

This project includes a Docker Compose setup for running both the frontend and backend in development mode with live reloading.

## Prerequisites

- Docker Desktop (or Docker Engine + Docker Compose)
- No need to install Ruby, Node.js, or any dependencies locally

## Quick Start

### First Time Setup

On first run, the database will be automatically created and migrations will run:

```bash
docker compose up
```

The backend service runs `bin/rails db:prepare` on startup, which will:
- Create the database if it doesn't exist
- Run migrations
- Load the schema

### Start all services

```bash
docker compose up
```

This will start:
- **PostgreSQL** (Database): localhost:5432
- **Backend** (Rails API): http://localhost:3000
- **Frontend** (React/Vite): http://localhost:5173
- **Jobs** (Solid Queue worker): Background job processor

### Start services in detached mode

```bash
docker compose up -d
```

### View logs

```bash
# All services
docker compose logs -f

# Specific service
docker compose logs -f backend
docker compose logs -f frontend
docker compose logs -f jobs
```

### Stop services

```bash
docker compose down
```

### Rebuild images (after Gemfile or package.json changes)

```bash
docker compose build
docker compose up
```

### Stop and remove volumes (deletes all data)

```bash
docker compose down -v
```

**Warning**: This will delete all PostgreSQL data. Use this to start completely fresh.

## Services

### PostgreSQL Database

- **Port**: 5432
- **Database**: myapp_development
- **Username**: postgres
- **Password**: postgres
- **Volume**: Persistent data storage in `postgres_data` volume

### Backend (Rails API)

- **Port**: 3000
- **Live Reload**: ✅ Changes to Ruby files are automatically reloaded
- **Volume Mount**: `./backend` → `/rails`
- **Database**: PostgreSQL (running in separate container)

### Frontend (React/Vite)

- **Port**: 5173
- **Hot Module Replacement**: ✅ Changes to React files update instantly
- **Volume Mount**: `./frontend` → `/app`
- **API Connection**: Configured to connect to backend at `http://localhost:3000`

### Jobs (Solid Queue Worker)

- Processes background jobs for the Rails application
- Shares the backend codebase and database

## Development Workflow

### 1. Make code changes

Edit files in `./frontend` or `./backend` directories. Changes will be automatically detected:
- **Frontend**: Vite HMR will hot-reload your changes
- **Backend**: Rails will reload the changed files on next request

### 2. Run Rails commands

```bash
# Database migrations
docker compose exec backend bin/rails db:migrate

# Create and seed database
docker compose exec backend bin/rails db:seed

# Rails console
docker compose exec backend bin/rails console

# Run tests
docker compose exec backend bundle exec rspec

# Generate models/controllers
docker compose exec backend bin/rails generate model MyModel

# Check database connection
docker compose exec backend bin/rails db:version
```

### 3. Run frontend commands

```bash
# Install new package
docker compose exec frontend npm install <package-name>

# Run linting
docker compose exec frontend npm run lint

# Run type checking
docker compose exec frontend npx tsc --noEmit
```

### 4. Install new dependencies

When you add gems or npm packages:

```bash
# After updating Gemfile
docker compose build backend
docker compose up -d backend

# After updating package.json
docker compose build frontend
docker compose up -d frontend
```

Or rebuild everything:

```bash
docker compose build
docker compose up -d
```

## Troubleshooting

### Port already in use

If ports 3000 or 5173 are already in use, modify `docker-compose.yml`:

```yaml
services:
  backend:
    ports:
      - "3001:3000"  # Change host port
  frontend:
    ports:
      - "5174:5173"  # Change host port
```

### Database issues

Reset the database:

```bash
docker compose exec backend bin/rails db:reset
```

Connect to PostgreSQL directly:

```bash
docker compose exec postgres psql -U postgres -d myapp_development
```

View database logs:

```bash
docker compose logs -f postgres
```

### Permission issues

If you encounter permission issues with volumes:

```bash
# Fix ownership (Linux/Mac)
sudo chown -R $USER:$USER backend/ frontend/
```

### Clean rebuild

Remove everything and start fresh:

```bash
docker compose down -v
docker compose build --no-cache
docker compose up
```

### Live reload not working

If file changes aren't being detected:

1. **Frontend**: Ensure `usePolling: true` is set in `vite.config.ts` (already configured)
2. **Backend**: Rails should auto-reload, but you can restart: `docker compose restart backend`

## Volume Performance

The setup uses:
- **Named volumes** for `node_modules` and gems (faster, isolated)
- **Bind mounts** for source code (enables live reloading)
- **Anonymous volumes** for `tmp` and `log` (avoids syncing temporary files)

## Running Individual Services

Run only specific services:

```bash
# Backend only
docker compose up backend

# Frontend only (requires backend for API calls)
docker compose up frontend backend

# Without jobs
docker compose up frontend backend
```

## Health Checks

The backend includes a health check endpoint:

```bash
curl http://localhost:3000/up
```
