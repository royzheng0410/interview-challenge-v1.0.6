import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true, // Listen on all addresses (needed for Docker)
    watch: {
      usePolling: true, // Enable polling for file changes in Docker
    },
    hmr: {
      clientPort: 5173, // Use the same port for HMR
    }
  }
})
