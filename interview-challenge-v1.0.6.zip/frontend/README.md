# Frontend Challenge

Welcome! This challenge covers performance optimization, state management, and accessibility in a React application.

## 📋 Important Files

- **[INSTRUCTIONS.md](./INSTRUCTIONS.md)**: Detailed task descriptions and requirements
- **[SOLUTIONS.md](./SOLUTIONS.md)**: Document your solutions and analysis here

## Quick Start

Use Docker Compose from the root directory:

```bash
# From project root
docker compose up
```

The application will open at `http://localhost:5173`.

See the root [DOCKER.md](../DOCKER.md) for detailed instructions.

## What to Submit

1. Your code changes
2. Completed `SOLUTIONS.md` with your analysis and approach
3. Any notes about trade-offs or decisions you made

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run lint` - Run ESLint
- `npx tsc --noEmit` - Run TypeScript type checking

Good luck!
