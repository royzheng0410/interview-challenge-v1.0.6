import { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react'

interface SearchContextType {
  filter: string
  setFilter: (filter: string) => void
  debouncedFilter: string
}

const SearchContext = createContext<SearchContextType | undefined>(undefined)

export const useSearch = (): SearchContextType => {
  const context = useContext(SearchContext)
  if (!context) {
    throw new Error('useSearch must be used within SearchProvider')
  }
  return context
}

interface SearchProviderProps {
  children: ReactNode
}

export const SearchProvider = ({ children }: SearchProviderProps) => {
  const [filter, setFilter] = useState('')
  const [debouncedFilter, setDebouncedFilter] = useState('') // Added to avoid request per keyboard stroke.

  useEffect(() => {
    const timeoutId = setTimeout(() => setDebouncedFilter(filter), 300)
    return () => clearTimeout(timeoutId)
  }, [filter])

  const value = useMemo(() => ({ filter, setFilter, debouncedFilter }), [filter, debouncedFilter])

  return (
    <SearchContext.Provider value={value}>
      {children}
    </SearchContext.Provider>
  )
}
