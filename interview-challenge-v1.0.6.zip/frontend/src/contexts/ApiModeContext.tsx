import { createContext, useContext, useState, useMemo, useCallback, ReactNode } from 'react'
import type { ApiMode } from '../types'
import type { DataService } from '../services/DataService'
import { DataServiceFactory } from '../services/DataServiceFactory'

interface ApiModeContextType {
  apiMode: ApiMode
  setApiMode: (mode: ApiMode) => void
  toggleApiMode: () => void
  isBackendMode: boolean
  isMockMode: boolean
  dataService: DataService // The active service instance
}

const ApiModeContext = createContext<ApiModeContextType | undefined>(undefined)

export const useApiMode = (): ApiModeContextType => {
  const context = useContext(ApiModeContext)
  if (!context) {
    throw new Error('useApiMode must be used within ApiModeProvider')
  }
  return context
}

interface ApiModeProviderProps {
  children: ReactNode
}

export const ApiModeProvider = ({ children }: ApiModeProviderProps) => {
  const getInitialMode = (): ApiMode => {
    const isDevelopment = import.meta.env.VITE_DEVELOPMENT === 'true'

    if (isDevelopment) {
      const savedMode = localStorage.getItem('apiMode') as ApiMode | null
      if (savedMode && (savedMode === 'mock' || savedMode === 'backend')) {
        return savedMode
      }
      return 'mock'
    }

    return 'backend'
  }

  const [apiMode, setApiModeState] = useState<ApiMode>(getInitialMode)

  const dataService = useMemo(() => {
    const service = DataServiceFactory.create(apiMode)
    console.log(`[ApiModeContext] Switched to: ${service.getServiceName()}`)
    return service
  }, [apiMode])

  const setApiMode = useCallback((mode: ApiMode) => {
    setApiModeState(mode)
    localStorage.setItem('apiMode', mode)
  }, [])

  const toggleApiMode = useCallback(() => {
    setApiModeState(current => {
      const newMode: ApiMode = current === 'mock' ? 'backend' : 'mock'
      localStorage.setItem('apiMode', newMode)
      return newMode
    })
  }, [])

  const value = useMemo(() => ({
    apiMode,
    setApiMode,
    toggleApiMode,
    isBackendMode: apiMode === 'backend',
    isMockMode: apiMode === 'mock',
    dataService, // Provide the service instance
  }), [apiMode, setApiMode, toggleApiMode, dataService])

  return (
    <ApiModeContext.Provider value={value}>
      {children}
    </ApiModeContext.Provider>
  )
}
