export interface Order {
  id: number
  total: number
}

export interface User {
  id: number
  name: string
  orders: Order[]
}

export interface Analytics {
  totalUsers: number
  totalOrders: number
  totalRevenue: number
  avgOrdersPerUser: number
  avgRevenuePerUser: number
}

export interface GraphQLOrder {
  id: string
  total: number
}

export interface GraphQLUser {
  id: string
  name: string
  orders: GraphQLOrder[]
}

export interface GraphQLUsersResponse {
  users: GraphQLUser[]
}

export type ApiMode = 'mock' | 'backend'
