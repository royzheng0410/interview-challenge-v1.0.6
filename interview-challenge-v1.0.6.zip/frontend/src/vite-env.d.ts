
interface ImportMetaEnv {
  readonly VITE_DEVELOPMENT: string
  readonly VITE_BACKEND_URL: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
