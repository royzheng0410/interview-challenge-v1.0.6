import { useState } from 'react'
import type { User } from '../types'

interface UserRowProps {
  user: User
  totalRevenue: number
  percentileRank: number
}

function UserRow({ user, totalRevenue, percentileRank }: UserRowProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  const handleToggle = () => {
    setIsExpanded(!isExpanded)
  }

  const avgOrderValue = user.orders.length > 0
    ? totalRevenue / user.orders.length
    : 0

  const revenueCategory = totalRevenue > 100000 ? '🌟 High Value'
    : totalRevenue > 50000 ? '💎 Medium Value'
    : totalRevenue > 0 ? '📊 Standard'
    : '💤 Inactive'

  return (
    <>
      <tr onClick={handleToggle}>
        <td>{user.name}</td>
        <td>{user.orders.length}</td>
        <td>
          ${totalRevenue.toLocaleString()}
          <div style={{ fontSize: '0.75rem', color: '#7f8c8d', marginTop: '4px' }}>
            {revenueCategory} • Top {100 - percentileRank}%
          </div>
        </td>
      </tr>
      {isExpanded && (
        <tr>
          <td colSpan={3} style={{ backgroundColor: '#f8f9fa', padding: '1rem' }}>
            <div>
              <strong>Order Details:</strong>
              {user.orders.length === 0 ? (
                <p>No orders yet</p>
              ) : (
                <>
                  <div style={{ marginBottom: '0.5rem' }}>
                    <strong>Avg Order Value:</strong> ${Math.round(avgOrderValue).toLocaleString()}
                  </div>
                  <ul>
                    {user.orders.map(order => (
                      <li key={order.id}>Order #{order.id}: ${order.total.toLocaleString()}</li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </td>
        </tr>
      )}
    </>
  )
}

export default UserRow
