import { useState } from 'react'
import UserTable from './UserTable'
import { useSearch } from '../contexts/SearchContext'
import type { User } from '../types'

interface DashboardProps {
  users: User[]
  loading: boolean
}

function Dashboard({ users, loading }: DashboardProps) {
  const [refreshKey, setRefreshKey] = useState(0)
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc')
  const { debouncedFilter } = useSearch()

  const filteredUsers = users.filter((user) => {
    return user.name.toLowerCase().includes(debouncedFilter.toLowerCase())
  })

  const sortedUsers = [...filteredUsers].sort((a, b) => {
    if (sortOrder === 'asc') {
      return a.name.localeCompare(b.name)
    } else {
      return b.name.localeCompare(a.name)
    }
  })

  const calculateMedianRevenue = () => {
    const revenues = filteredUsers.map(u =>
      u.orders.reduce((sum, order) => sum + order.total, 0)
    ).sort((a, b) => a - b)
    if (revenues.length === 0) return 0
    const mid = Math.floor(revenues.length / 2)
    return revenues.length % 2 === 0
      ? (revenues[mid - 1] + revenues[mid]) / 2
      : revenues[mid]
  }
  const medianRevenue = calculateMedianRevenue()

  const calculateTopPerformerThreshold = () => {
    const revenues = filteredUsers.map(u =>
      u.orders.reduce((sum, order) => sum + order.total, 0)
    ).sort((a, b) => b - a)
    const topTenPercentIndex = Math.floor(revenues.length * 0.1)
    return revenues[topTenPercentIndex] || 0
  }
  const topPerformerThreshold = calculateTopPerformerThreshold()

  if (loading) {
    return <div className="dashboard"><div className="loading">Loading...</div></div>
  }

  return (
    <div className="dashboard">
      <div className="controls">
        <div className="btn" onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}>
          Sort: {sortOrder === 'asc' ? '↑' : '↓'}
        </div>
        <div className="btn" onClick={() => setRefreshKey(refreshKey + 1)}>
          Refresh
        </div>
        <div style={{ marginLeft: 'auto', fontSize: '0.85rem', color: '#7f8c8d' }}>
          Showing {filteredUsers.length} of {users.length} users •
          Median: ${Math.round(medianRevenue).toLocaleString()} •
          Top 10%: ${Math.round(topPerformerThreshold).toLocaleString()}
        </div>
      </div>

      <UserTable users={sortedUsers} allUsers={users} key={refreshKey} />
    </div>
  )
}

export default Dashboard
