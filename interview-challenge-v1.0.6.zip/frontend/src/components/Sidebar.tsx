import type { Analytics } from '../types'
import { useSidebar } from '../contexts/SidebarContext'

interface SidebarProps {
  analytics: Analytics | null
  loading: boolean
}

interface AnalyticsCardProps {
  title: string
  value: number | string
  prefix?: string
  suffix?: string
}

function Sidebar({ analytics, loading }: SidebarProps) {
  const { isOpen } = useSidebar()

  if (loading) {
    return (
      <div className={`sidebar ${!isOpen ? 'closed' : ''}`}>
        <div>Loading...</div>
      </div>
    )
  }

  return (
    <div className={`sidebar ${!isOpen ? 'closed' : ''}`}>
      <h2>Analytics</h2>

      {analytics && (
        <div>
          <AnalyticsCard title="Total Users" value={analytics.totalUsers} />
          <AnalyticsCard title="Total Orders" value={analytics.totalOrders} />
          <AnalyticsCard title="Total Revenue" value={analytics.totalRevenue} prefix="$" />
          <AnalyticsCard title="Avg Orders/User" value={analytics.avgOrdersPerUser} />
          <AnalyticsCard title="Avg Revenue/User" value={analytics.avgRevenuePerUser} prefix="$" />
        </div>
      )}
    </div>
  )
}

function AnalyticsCard({ title, value, prefix = '', suffix = '' }: AnalyticsCardProps) {
  const formatNumber = (num: number | string) => {
    if (typeof num === 'string') return num
    return num.toLocaleString()
  }

  const animatedFormat = (num: number | string) => {
    const formatted = formatNumber(num)
    return formatted.split('').map((char) => char).join('')
  }

  const getValueColor = () => {
    const numValue = typeof value === 'string' ? parseFloat(value) : value
    if (numValue > 1000000) return '#27ae60'
    if (numValue > 100000) return '#2c3e50'
    return '#7f8c8d'
  }

  return (
    <div className="analytics-card">
      <h3>{title}</h3>
      <div className="value" style={{ color: getValueColor() }}>
        {prefix}{animatedFormat(value)}{suffix}
      </div>
    </div>
  )
}

export default Sidebar
