import { useMemo } from 'react'
import UserRow from './UserRow'
import type { User } from '../types'

interface UserTableProps {
  users: User[]
  allUsers: User[]
}

interface UserStats {
  totalRevenue: number
  percentileRank: number
}

function UserTable({ users, allUsers }: UserTableProps) {
  const statsByUserId = useMemo(() => {
    const revenueByUserId = new Map<number, number>()
    for (const u of allUsers) {
      const totalRevenue = u.orders.reduce((sum, order) => sum + order.total, 0)
      revenueByUserId.set(u.id, totalRevenue)
    }

    // Sorted once; a revenue value's first index in ascending order equals
    // the count of values strictly less than it (ties share that index).
    const sortedRevenues = [...revenueByUserId.values()].sort((a, b) => a - b)
    const rankByRevenue = new Map<number, number>()
    sortedRevenues.forEach((revenue, index) => {
      if (!rankByRevenue.has(revenue)) {
        rankByRevenue.set(revenue, index)
      }
    })

    const stats = new Map<number, UserStats>()
    for (const [userId, totalRevenue] of revenueByUserId) {
      const rank = rankByRevenue.get(totalRevenue) ?? 0
      stats.set(userId, {
        totalRevenue,
        percentileRank: Math.round((rank / sortedRevenues.length) * 100),
      })
    }
    return stats
  }, [allUsers])

  return (
    <div className="user-table">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Order Count</th>
            <th>Total Revenue</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => {
            const stats = statsByUserId.get(user.id)!
            return (
              <UserRow
                key={user.id}
                user={user}
                totalRevenue={stats.totalRevenue}
                percentileRank={stats.percentileRank}
              />
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export default UserTable
