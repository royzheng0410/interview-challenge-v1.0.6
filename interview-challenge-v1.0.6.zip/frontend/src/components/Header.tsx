import { useApiMode } from '../contexts/ApiModeContext'
import { useSidebar } from '../contexts/SidebarContext'
import { useSearch } from '../contexts/SearchContext'

function Header() {
  const { toggleApiMode, isBackendMode } = useApiMode()
  const { toggle } = useSidebar()
  const { filter, setFilter } = useSearch()
  const isDevelopment = import.meta.env.VITE_DEVELOPMENT === 'true'

  return (
    <div className="header">
      <div className="hamburger" onClick={toggle}>
        ☰
      </div>
      <h1>User Dashboard</h1>

      {/* API Mode Toggle - Only show in development mode */}
      {isDevelopment && (
        <div className="api-mode-toggle">
          <span className="toggle-label">Mock Data</span>
          <label className="switch">
            <input
              type="checkbox"
              checked={isBackendMode}
              onChange={toggleApiMode}
            />
            <span className="slider"></span>
          </label>
          <span className="toggle-label">Backend API</span>
          {isBackendMode && (
            <span className="backend-indicator" title="Connected to Rails backend">
              🟢
            </span>
          )}
        </div>
      )}

      <input
        type="text"
        className="search-box"
        placeholder="Search users..."
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
      />
    </div>
  )
}

export default Header
