
import type { DataService } from './DataService'
import type { ApiMode } from '../types'
import { MockDataService } from './MockDataService'
import { BackendDataService } from './BackendDataService'

/**
 * DataServiceFactory - Creates the appropriate service based on API mode
 *
 * This factory encapsulates the logic for choosing which implementation to use,
 * keeping the rest of the app agnostic to the data source.
 */
export class DataServiceFactory {
  /**
   * Create a DataService instance for the given mode
   *
   * @param mode - 'mock' or 'backend'
   * @returns DataService implementation
   */
  static create(mode: ApiMode): DataService {
    switch (mode) {
      case 'mock':
        return new MockDataService()

      case 'backend':
        return new BackendDataService()

      default:
        console.warn(`Unknown API mode: ${mode}, defaulting to mock`)
        return new MockDataService()
    }
  }
}
