
import { GraphQLClient } from 'graphql-request'
import type { User, Analytics } from '../types'
import type { DataService } from './DataService'
import type { GraphQLUsersResponse, GraphQLUser } from '../types'
import { AnalyticsCalculator } from './AnalyticsCalculator'

const BACKEND_URL = (import.meta.env.VITE_BACKEND_URL as string) || 'http://localhost:3000'

const USERS_QUERY = `
  query GetUsers {
    users {
      id
      name
      orders {
        id
        total
      }
    }
  }
`

/**
 * BackendDataService - Fetches data from Rails GraphQL API
 * Used for:
 * - Full-stack integration testing
 * - Demo with real backend
 * - Development of backend features
 */
export class BackendDataService implements DataService {
  private readonly client: GraphQLClient
  private cachedUsers: User[] | null = null

  constructor() {
    this.client = new GraphQLClient(`${BACKEND_URL}/graphql`, {
      headers: {
        'Content-Type': 'application/json',
      },
    })
  }

  async fetchUsers(): Promise<User[]> {
    try {
      const data = await this.client.request<GraphQLUsersResponse>(USERS_QUERY)
      this.cachedUsers = data.users.map(this.transformUser)
      return this.cachedUsers
    } catch (error) {
      console.error('[BackendDataService] Failed to fetch users:', error)
      throw new Error('Failed to fetch users from backend API')
    }
  }

  async fetchAnalytics(): Promise<Analytics> {
    try {
      const users = this.cachedUsers || await this.fetchUsers()

      return AnalyticsCalculator.calculate(users)
    } catch (error) {
      console.error('[BackendDataService] Failed to fetch analytics:', error)
      throw new Error('Failed to fetch analytics from backend API')
    }
  }

  getServiceName(): string {
    return 'BackendDataService'
  }

  /**
   * Transform GraphQL user to frontend User type
   * Converts string IDs to numbers and transforms orders
   */
  private transformUser(graphqlUser: GraphQLUser): User {
    return {
      id: parseInt(graphqlUser.id),
      name: graphqlUser.name,
      orders: graphqlUser.orders.map(order => ({
        id: parseInt(order.id),
        total: order.total,
      })),
    }
  }
}
