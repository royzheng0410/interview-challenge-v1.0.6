
import type { User, Analytics, Order } from '../types'
import type { DataService } from './DataService'
import { AnalyticsCalculator } from './AnalyticsCalculator'

const FIRST_NAMES = [
  'Alex', 'Blake', 'Casey', 'Drew', 'Ellis', 'Finley', 'Gray', 'Harper', 'Jordan', 'Morgan',
  'Riley', 'Sage', 'Taylor', 'Quinn', 'Avery', 'Cameron', 'Devon', 'Emerson', 'Kendall', 'Logan',
  'Parker', 'Reese', 'Skylar', 'Sidney', 'Rowan', 'Sawyer', 'Phoenix', 'River', 'Bailey', 'Charlie',
  'Dakota', 'Elliott', 'Frankie', 'Harley', 'Indigo', 'Jules', 'Kai', 'Lane', 'Marley', 'Nova',
  'Oakley', 'Peyton', 'Quincy', 'Remy', 'Shiloh', 'Tatum', 'Unity', 'Vale', 'Winter', 'Zion',
  'Adrian', 'Blair', 'Cedar', 'Dylan', 'Eden', 'Fallon', 'Gray', 'Haven', 'Iris', 'Jude',
  'Kit', 'Luca', 'Micah', 'Nico', 'Ocean', 'Paris', 'Raven', 'Sam', 'Trace', 'Vic'
]

const MIDDLE_NAMES = [
  'Lee', 'Ray', 'Mae', 'Lou', 'James', 'Marie', 'Rose', 'Grace', 'Lynn', 'Ann',
  'Jean', 'Kay', 'Jo', 'Dale', 'Jay', 'Rae', 'Dawn', 'Faye', 'Belle', 'Jane',
  'Claire', 'Mae', 'Ruth', 'Pearl', 'Sky', 'Wren', 'Blaine', 'Blake', 'Cole', 'Drew',
  'Flynn', 'Gray', 'Hope', 'Jade', 'Jules', 'Lane', 'Max', 'Paige', 'Quinn', 'Reed',
  'Sage', 'Tate', 'Vale', 'Wade', 'Zane', 'Beau', 'Cruz', 'Dean', 'Elle', 'Finn'
]

const LAST_NAMES = [
  'Anderson', 'Brown', 'Clark', 'Davis', 'Evans', 'Fisher', 'Green', 'Harris', 'Jones', 'Miller',
  'Moore', 'Taylor', 'Thomas', 'White', 'Martin', 'Thompson', 'Garcia', 'Martinez', 'Robinson', 'Rodriguez',
  'Lewis', 'Walker', 'Hall', 'Allen', 'Young', 'King', 'Wright', 'Lopez', 'Hill', 'Scott',
  'Adams', 'Baker', 'Carter', 'Diaz', 'Edwards', 'Flores', 'Gonzalez', 'Hernandez', 'Jackson', 'Kelly',
  'Long', 'Mitchell', 'Nelson', 'Owens', 'Parker', 'Quinn', 'Reed', 'Sanders', 'Torres', 'Underwood',
  'Vasquez', 'Watson', 'Xavier', 'Yang', 'Zhang', 'Bennett', 'Collins', 'Dixon', 'Ellis', 'Foster',
  'Gray', 'Hayes', 'Irwin', 'Jenkins', 'Kennedy', 'Lawson', 'Morgan', 'Murphy', 'Nguyen', 'Ortiz'
]

/**
 * MockDataService - Generates mock data client-side
 * Used for:
 * - Performance testing with large datasets (2500+ users)
 * - Development without backend
 * - Candidate interviews (default mode)
 */
export class MockDataService implements DataService {
  private readonly userCount: number
  // Static, not instance-level: the generated dataset is deterministic and
  // identical regardless of which instance creates it, so it's shared across
  // instances rather than lost every time ApiModeContext creates a new one.
  private static cachedUsers: User[] | null = null

  constructor(userCount: number = 2500) {
    this.userCount = userCount
  }

  async fetchUsers(): Promise<User[]> {
    if (MockDataService.cachedUsers) {
      return MockDataService.cachedUsers
    }

    await this.delay(1500)
    MockDataService.cachedUsers = this.generateMockUsers(this.userCount)
    return MockDataService.cachedUsers
  }

  async fetchAnalytics(): Promise<Analytics> {
    const isFreshFetch = MockDataService.cachedUsers === null
    const users = await this.fetchUsers()

    if (isFreshFetch) {
      await this.delay(800)
    }

    return AnalyticsCalculator.calculate(users)
  }

  getServiceName(): string {
    return 'MockDataService'
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms))
  }

  /**
   * Generate deterministic mock users
   */
  private generateMockUsers(count: number): User[] {
    const users: User[] = []
    let nextOrderId = 100

    for (let i = 0; i < count; i++) {
      const orders = this.generateOrders(i, nextOrderId)

      users.push({
        id: i + 1,
        name: this.generateDeterministicName(i),
        orders: orders,
      })

      nextOrderId += orders.length
    }

    return users
  }

  /**
   * Generate a deterministic name based on index
   */
  private generateDeterministicName(index: number): string {
    const firstIndex = index % FIRST_NAMES.length
    const lastIndex = Math.floor(index / FIRST_NAMES.length) % LAST_NAMES.length
    const middleIndex = Math.floor(index / (FIRST_NAMES.length * LAST_NAMES.length)) % MIDDLE_NAMES.length

    const includeMiddle = index % 3 === 0

    const firstName = FIRST_NAMES[firstIndex]
    const lastName = LAST_NAMES[lastIndex]

    if (includeMiddle) {
      const middleName = MIDDLE_NAMES[middleIndex]
      return `${firstName} ${middleName} ${lastName}`
    }

    return `${firstName} ${lastName}`
  }

  /**
   * Generate deterministic orders for a user based on their index
   */
  private generateOrders(userIndex: number, startOrderId: number): Order[] {
    const hash = (userIndex * 17 + 13) * (userIndex * 23 + 7)
    const countVariation = Math.abs(hash % 100)

    let orderCount: number
    if (countVariation < 10) orderCount = 0
    else if (countVariation < 25) orderCount = 1
    else if (countVariation < 45) orderCount = 2
    else if (countVariation < 65) orderCount = 3
    else if (countVariation < 80) orderCount = 4
    else if (countVariation < 90) orderCount = 5
    else if (countVariation < 95) orderCount = 6
    else if (countVariation < 98) orderCount = 7
    else orderCount = 8

    const orders: Order[] = []
    for (let i = 0; i < orderCount; i++) {
      const baseTotal = 5000 + ((userIndex * 7 + i * 11) % 50000)

      orders.push({
        id: startOrderId + i,
        total: baseTotal,
      })
    }
    return orders
  }
}
