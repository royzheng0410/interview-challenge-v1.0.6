
import type { User, Analytics } from '../types'

export class AnalyticsCalculator {
  /**
   * Calculate analytics from user data
   * All metrics are derived from actual user and order properties
   */
  static calculate(users: User[]): Analytics {
    const totalUsers = users.length

    const totalOrders = users.reduce((sum, u) => sum + u.orders.length, 0)
    const totalRevenue = users.reduce((sum, u) =>
      sum + u.orders.reduce((orderSum, order) => orderSum + order.total, 0)
    , 0)

    const avgOrdersPerUser = totalUsers > 0 ? totalOrders / totalUsers : 0
    const avgRevenuePerUser = totalUsers > 0 ? Math.round(totalRevenue / totalUsers) : 0

    return {
      totalUsers,
      totalOrders,
      totalRevenue,
      avgOrdersPerUser: Math.round(avgOrdersPerUser * 100) / 100, // Round to 2 decimals
      avgRevenuePerUser,
    }
  }
}
