
import type { User, Analytics } from '../types'

/**
 * DataService interface - defines the contract for data fetching
 * Implementations can fetch from different sources (mock data, API, etc.)
 */
export interface DataService {
  /**
   * Fetch all users
   */
  fetchUsers(): Promise<User[]>

  /**
   * Fetch analytics data
   */
  fetchAnalytics(): Promise<Analytics>

  /**
   * Get the name/type of this service (for debugging)
   */
  getServiceName(): string
}
