import { useState, useEffect } from 'react'
import './App.css'
import Dashboard from './components/Dashboard.tsx'
import Sidebar from './components/Sidebar.tsx'
import Header from './components/Header.tsx'
import { useApiMode } from './contexts/ApiModeContext'
import { SidebarProvider } from './contexts/SidebarContext'
import { SearchProvider } from './contexts/SearchContext'
import type { User, Analytics } from './types'

function App() {
  const { dataService } = useApiMode()
  const [users, setUsers] = useState<User[]>([])
  const [analytics, setAnalytics] = useState<Analytics | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      setUsers([])
      setAnalytics(null)
      setLoading(true)

      try {
        const usersData = await dataService.fetchUsers()
        const analyticsData = await dataService.fetchAnalytics()
        setUsers(usersData)
        setAnalytics(analyticsData)
      } catch (error) {
        console.error('Failed to load data:', error)
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [dataService])

  return (
    <SidebarProvider>
      <SearchProvider>
        <div className="app">
          <Header />
          <div className="app-container">
            <Sidebar
              analytics={analytics}
              loading={loading}
            />
            <Dashboard
              users={users}
              loading={loading}
            />
          </div>
        </div>
      </SearchProvider>
    </SidebarProvider>
  )
}

export default App
