# Solutions Document

**Candidate Name**: Chen Zheng
**Date**: 12th Oct, 2026

## Instructions

Please document your approach, decisions, and solutions below. This helps us understand your thinking process even for items you didn't have time to complete.

---

## 1. Performance Optimizations

### Issues Identified
List the performance issues you found:

1. Slow switch between mock data/live API mode
2. Slow sidebar toggle (it's a side effect of slow mockdata fetch because switching sidebar triggers a re-render of dashboard)
3. Slow user search

### Solutions Implemented
Describe what you fixed and why:

#### Solution 1:
- **What**:
Move cachedUser to class level so that it will survive across MockDataService initialisation to avoid rebuild users from mock data
- **Why**:
Currently mock user has to be rebuilt everetime the user switch back to mock data mode, because it was cached at instance level which will be wiped out when swithing away
- **How**:
Store the cachedUsers at the class level using private static
- **Impact**:
40% improvement in LCP

#### Solution 2:
- **What**:
Move the user stats (total rev + percentile) calculation from UserRow to UserTable under useMemo
- **Why**:
User stats were calculated time and time again at each UserRow level, which is very expensive
- **How**:
Move the calculation up to UserTable, where a user id to user stats mapping is built and memoised for subsequent rendering.
- **Impact**:
a futher 30% improvement on LCP


### Performance Measurements
If you measured performance before/after:

- **Before**:
LCP 5.8s
- **After**:
LCP 2s
- **Methodology**:
Used Performance tracking in the browser DevTool to track Largest Contentful Paint (LCP) on page initial load
---

## 2. State Management

### Issues Identified
List the state management issues you found:

1. App.txs includes all states that should not be its concern, e.g. sidebar, header
2. Mixed data and UI state
3. Lack of error handling

### Solutions Implemented

#### Solution 1:
- **What**:
Untangle states in App.tsx
- **Why**:
App.tsx includes both UI and Data related states which results in unnecessary re-rendering
- **How**:
	- Move state management to where it matters
		- Move sortOrder to Dashboard
		- Create SidebarContext for sidebarOpen state, which consumes by Header and Sidebar
		- Create SearchContext for filter, debouncedFilter state to it, which consumes by Header and Dashboard
- **Trade-offs**:
Having a single UI context for managing all UI related states, which my simplify code but would trigger unnecessary re-rendering when different consumer shares different interest in the managed states.
---

## 3. Payload Optimization

### Issues Identified
List the payload/bundle size issues you found:

1. No pagination on users.
2. Some computations (e.g. ananlytics) could be done on server side.
3. Mock data will be bundled for production, which is not needed.

### Solutions Implemented

#### Solution 1:
- **What**:
- **Why**:
- **How**:
- **Estimated Impact**:

### What I Would Do With More Time

Look at if there's N+1 issue at GraphQL level and fix it with dataloader.

---

## 4. Accessibility

### Issues Identified
List the accessibility issues you found:

1. Buttons are using div tag instead of button.
2. No HTML landmarks such as header, main, etc.
3. No label for the free form input search bar.

### Solutions Implemented

#### Solution 1:
- **What**:
- **Why**:
- **WCAG Criterion**:
- **How to Test**:

---

## 5. Architecture Discussion

### SSR vs CSR for This Application

**My Recommendation**:
Keep it as CSR

**Reasoning**:
This seems to be a internal page that serves private data behind an authenticated gate, which does not have a lot of SEO/Search engine index requirement

**Trade-offs Considered**:
- Pros:
  - Separate of concerns, which makes it easier for team setup, e.g frontend and backend team.
  - Bundle of the whole app could be served from CDN without touching the server.
- Cons:
  - Slow initial load time compare to SSR
  - Lack support for SEO/Search engine indexing.

### Production Readiness

If I were deploying this to production, I would add:

1. Add tests
2. Add CI/CD pipeline
3. Integrate with Observability tool

### Performance Monitoring

How I would monitor this application in production:

- **Metrics to track**:
   - Core web vitals
   - Custom duration metrics for some know slow flows
   - API requests latency
   - General error rates
- **Tools to use**:
   - Datadog RUM, APM, Metrics, Monitors and Synthetic tests
   - Tools like Rollbar for error tracking
- **Alerting strategy**:
   - When a certain metrics is over a threashold, e.g. LCP > 4s.
   - When a Synthetic tests failed, e.g. a certain action flow is broken on the website.
   - Connect the DD monitor to tools such as PagerDuty to page the oncaller to responde.

---

## 6. Prioritization

### If I Had Only 1 More Hour

The top 3 things I would work on:

1. **Priority 1**:
   - Why: Add pagination
   - Expected impact: Have a limited set of the user to show at a time, then load more via pagination (either explicit page or infinite scroll.). The pagination could be done at server or client side depends on requirement.

2. **Priority 2**:
   - Why: Fix a11y issues
   - Expected impact: To make the page friendly for people who needs special needs, at least key board accessible.

3. **Priority 3**:
   - Why: Add tests
   - Expected impact: To give the team confidence to ship this into production.

---

## 7. Reflection

### What Went Well
- Thorough instruction to setup the project
- Fun tasks to tackle

### What Was Challenging
- Meature performance
- Be able to finish everything within timeframe

### What I Learned
- A lot about React, hooks, state management, React DevTool, etc

### Questions for the Team
- What's the team's view on SSR vs CSR?
- What's the propotion of frontend vs backend work in day to day?

