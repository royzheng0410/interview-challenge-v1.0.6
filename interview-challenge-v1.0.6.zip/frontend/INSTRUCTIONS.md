# Frontend Challenge - Take Home Test

Welcome! This challenge assesses your frontend development skills through a realistic scenario.

## Time Allocation

This challenge typically takes **2-3 hours**, but we understand schedules vary. You don't need to complete everything - we're more interested in your approach, reasoning, and the quality of what you do implement.

**If you have limited time:** Focus on 1-2 high-impact issues and clearly document what you would tackle next. Quality over quantity.

## The Scenario

You've inherited a product dashboard application that displays user analytics. The application is functional but needs improvement before it can be considered production-ready.

## Setup

Start the development environment with Docker Compose from the project root:

```bash
# From project root
docker compose up
```

The application will open at `http://localhost:5173`.

See the root [DOCKER.md](../DOCKER.md) for detailed setup instructions.

## Your Task

Review the application and improve it across these areas:

### 1. Performance
Identify and resolve any performance bottlenecks in the application.

### 2. State Management
Evaluate and improve how the application manages state.

### 3. Accessibility
Ensure the application is accessible to all users.

### 4. Code Quality & Architecture
Identify architectural improvements and apply best practices.

## Deliverables

### 1. Code Changes
- Implement your improvements
- Add comments explaining your reasoning

### 2. SOLUTIONS.md
Complete the provided `SOLUTIONS.md` template documenting:
- Issues you identified
- Solutions you implemented
- Rationale for your decisions
- What you would do with more time
- Any trade-offs you considered

### 3. Performance Assessment
Provide evidence of improvements (qualitative or quantitative).

## Evaluation

We evaluate candidates on:
- **Problem Identification**: Can you spot issues and understand their impact?
- **Technical Solutions**: Are your fixes effective and well-implemented?
- **Code Quality**: Is your code clean, maintainable, and following best practices?
- **Communication**: Can you clearly explain your decisions and trade-offs?

## Guidelines

- **Prioritize based on impact** - Don't try to fix everything
- **Quality over quantity** - Better to fix one thing well than many things poorly
- **Document your thinking** - Explain why you chose to work on specific issues
- **Use any tools you'd normally use** - DevTools, documentation, etc.
- **If you run out of time** - Document what you would tackle next and why
- **Ask questions** if requirements are unclear

## Architecture Discussion

Be prepared to discuss:
- Your approach to solving these problems
- Trade-offs you considered
- How you would scale this application
- Production considerations (monitoring, error handling, etc.)

## Getting Started

1. Run the application and interact with it
2. Review the codebase to understand the structure
3. Identify areas for improvement
4. Implement and document your solutions

Good luck!
